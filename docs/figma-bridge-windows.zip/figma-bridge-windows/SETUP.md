# Figma MCP Express — Windows setup (2 minutes)

This plugin lets the coding agent on your Linux machine (192.168.11.202)
design directly inside your Figma file, live.

## Steps

1. Copy this whole folder (`figma-bridge-windows`) to a permanent place on
   Windows, e.g. `C:\figma-bridge`.

2. Open Figma Desktop (Windows) and log in as esmymohamed2@gmail.com.
   Open the file: https://www.figma.com/design/fxVLate2m1xbwr1jTbj6HA/smart-website

3. Plugins menu (top-left, the "smiley" icon) →
   Development → Import plugin from manifest…
   → select `C:\figma-bridge\plugin\manifest.json`

4. Run the plugin: Plugins → Development → "Figma MCP Express"
   (you may need to reload the file after importing)

5. In the plugin UI, set the server address to:
   - Host: `192.168.11.202`
   - Port: `1994`
   (the plugin defaults to 127.0.0.1 — change it to the Linux machine's IP)

6. Keep the plugin running, then tell the agent: "connected"

That's it. The agent will create the design tokens + design system
frames directly in your file.
